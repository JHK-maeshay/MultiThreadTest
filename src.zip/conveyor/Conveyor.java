package conveyor;

import item.Product;
import controller.Receiver;

import java.util.Queue;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Logger;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Conveyor{
    private static int counter = 0;  // 공유 카운터
    
    private final String name;
    private final Queue<Product> queue;
    private long length;
    private int lengthInt;
    private final Logger logger;
    private final long delayMillis;
    private final Receiver target;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public Conveyor(Queue<Product> queue, long length, Logger logger, Receiver target){
    		this.queue = queue;
        this.length = length;
        this.lengthInt = (int)length;
        this.logger = logger;
        this.delayMillis = length*1000;
        this.target = target;
        target.registerCallback(this::flushRetryQueue);
        counter++;  // 객체 생성될 때 counter 증가
        this.name = this.getClass().getSimpleName() + counter;
    }
    //length 미지정시 디폴트 10 -> 구현안함
    //

    public String getName() {
        return name;
    }

    //Conveyor 입력부
    public void addProduct(Product p) {
        scheduler.schedule(() -> {
            if (target != null) {
                target.receive(p);
            }
        }, delayMillis, TimeUnit.MILLISECONDS);//지연시간
    }
    
    private synchronized void flushRetryQueue() {
        Iterator<Product> it = queue.iterator();
        while (it.hasNext()) {
            Product p = it.next();
            if (target.receive(p)) {
                it.remove(); // 전달 성공 → 제거
            } else {
                break; // 더 이상 시도하지 않음
            }
        }
    }
    
    private synchronized void tryDeliver(Product p) {
        if (!target.receive(p)) {
            queue.add(p);
        }
    }
}
